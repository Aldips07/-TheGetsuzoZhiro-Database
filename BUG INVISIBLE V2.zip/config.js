require("./database/module")

//GLOBAL PAYMENT
global.storename = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.dana = "083119845366"
global.qris = "https://deposit.pictures/p/8f3f4ab89de24d3faef51146d7439b3a"


// GLOBAL SETTING
global.nameCreator = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.owner = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.namabot = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.nomorbot = "48699543580"
global.namaCreator = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.linkyt = "https://whatsapp.com/channel/0029VaZRiKK9WtCDBmbSKn0u"
global.autoJoin = false
global.antilink = false
global.versisc = '5.0'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://8030.us.kg/file/14VKdVW6MSA1.jpg'
global.isLink = 'https://whatsapp.com/channel/0029ValbDPt6WaKwXIRaHM0P'
global.packname = "Bugs"
global.author = "🩸⃟༑⌁⃰⃰𝐅𝐚𝐚 𝐎𝐟𝐜梨🐉"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})